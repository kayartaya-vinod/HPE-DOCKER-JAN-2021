package com.hpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
